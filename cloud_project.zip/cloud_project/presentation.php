<!DOCTYPE html>
<html>
  <head>
    <title>Login</title>
    <link rel="stylesheet" href="./style/style_presentation.css">
  </head>
  <body>
    <div class="presentation">
      <h1 class="titolo" >Cloud Project</h1>
      <h3 class="subtitolo">By Macedo Mason & Sartori</h3>
    </div>
    <div class="go-here">
      <a href="login.php"  class="btn-go" data-toggle="modal" data-target="#pop_login">
      Go here </a>
    </div>
  </body>
</html>