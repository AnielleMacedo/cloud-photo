<?php 

session_start();//uso sessione per fare reload page with f5 e evitare reinserire stessi dati su db

require './db/connection.php';

$message = '';

if(isset($_POST['login-but'])) {

  //controllo username duplicate
  $qry = "SELECT * FROM login WHERE username='" .$_POST['username']."' ";
  $result_user= $conn->prepare($qry);
  $result_user->execute();
  if ($result_user->fetchColumn() > 0) { 
    $message = "username";
  }

  //controllo email
  elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $message = "error-email";
  }

  //controllo pwd 
  elseif ($_POST['password'] !=  $_POST['confirm_password']) {
    $message = "password";
  }
  
  else{
    $sql = "INSERT INTO login (name, username, email, password) VALUES (:name, :username, :email, :password)";
    $stmt = $conn->prepare($sql);

    $name_cap = strtoupper(trim($_POST['name']));
    $stmt->bindParam(':name', $name_cap);

    $username_cap = strtolower(trim($_POST['username'])); 
    $stmt->bindParam(':username',$username_cap);

    $pwd_hash = password_hash($_POST['password'], PASSWORD_BCRYPT);//pwd criptata prima del invio
    $stmt->bindParam(':password', $pwd_hash);


    $email_lower = strtolower($_POST['email']);
    $stmt->bindParam(':email', $email_lower);
    
    if ($stmt->execute()) { 
      //uso la session per aggiornare le variab. qdo premo f5 su browser
      $_SESSION['message'] = "New user has been successfully created! You can login.";
      clean_fields();
      header('Location: register.php');
      exit;
    } 
    else {
      $message = "There was an error with your registration. Try again.";
    }    
  }

  if($message == "username"){
   $message= "This username or email already exists.Please choose another one.";

  }if($message == "error-email"){
    $message = "Email address missing point or incomplete! ";  

  }if($message == "password") {
    $message= "Password don't match.Please type again.";
  }

}


function clean_fields(){
  $_POST['name']= $_POST['username']= $_POST['email']= $_POST['password']=$_POST['confirm_password']='';
}

?>


<!DOCTYPE html>
<html>
  <head>
    <title>Registration</title>
    <link rel="stylesheet" href="./style/style_register.css?version=12">
  </head>
  <body>

    <?php //msg success
        if(isset($_SESSION['message'])): ?>
          <p class="msg-success"><?= $_SESSION['message']; unset($_SESSION['message']) ?></p>
    <?php endif; ?> 
            
    <?php //msg errore 
    if(!empty($message)): ?>
      <p class="msg-error"><?= $message ?></p>
    <?php endif; ?>
    
    
    <div id="form-block">
      <div id="form-block--left">
        <div id="left-content" >
          <h1>Register your account</h1>
         
          <form action="register.php" method="POST">
            <input name="name" type="text" placeholder="Name" value="<?php echo htmlentities(isset($_POST["name"]) ? $_POST["name"] : "");  ?>" required> <!--required torna il form fields obligat-->
            <input name="username" type="text" placeholder="Username" value="<?php echo htmlentities(isset($_POST["username"]) ? $_POST["username"] : "");  ?>" required>
            <input name="email" type="email" placeholder="Email Address" value="<?php echo htmlentities(isset($_POST["email"]) ? $_POST["email"] : "");  ?>" required>
            <input name="password" type="password" placeholder="Enter your Password" value="<?php echo htmlentities(isset($_POST["password"]) ? $_POST["password"] : "");  ?>" required>
            <input name="confirm_password" type="password" placeholder="Confirm your Password" value="<?php echo htmlentities(isset($_POST["confirm_password"]) ? $_POST["confirm_password"] : ""); ?>" required>
            <input id="check-btn" class="login-button" type="submit" value="Register" name="login-but">
          </form>
        </div>
        <div class="bottom-account">Already have an account?<a class="email-link" href="login.php" title="Sign in by credentials">Login&#8594;</a></div>
      </div>
      <!--div da imagem-->
      <div id="form-block--right"><img src="./images/cloud10.jpg" style="background-size: cover"></div>
      
    </div>
  </body>
  </html>