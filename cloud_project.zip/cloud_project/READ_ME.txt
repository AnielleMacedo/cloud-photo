#Observations

# Inizio progetto: http://localhost/cloud_project/

# Nella cartella cloud_project si trova il file di login, il file di registrazione, presentazione e una homepage da modificare per l'inserzione delle immagini e tag future.

# Nella cartella 'db' si trova il file cloud.sql che potreste importare in phpmyadmin per fare funzionare l'ingresso con login e registrazione.

# Se usate linux per aprire il progetto, su file connection nella cartella db, mettere sulla variabile $password la vostra password di msql, se avete, altrimenti lasciate vuota.

# Per accedere al database attraverso il login si entra com un username esistente (ex: anielle o mason o sartori), con attenzione al case sensitive e la password: its2019 che è stata criptata.

# A volte Chrome non aggiorna CSS files php per un problema di cache, perciò ho aggiunto la versione 12 al  href ex: <link href="style/style_register2.css?version=12">. Se ancora non aggiorna bene pulire il cache o usare un altro browser.

# Nel progetto esistono 2 opzioni di file de login (login.php e login2.php -> http://localhost/cloud_project/login2.php) da scegliere uno definitivo.

