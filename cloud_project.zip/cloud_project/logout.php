<?php
session_start();
unset($_SESSION["username"]);//destroy la session e impedisce accesso a home senza login
header("location: presentation.php");//redirect


?>