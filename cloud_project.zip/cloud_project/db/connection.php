<?php
$dsn = 'mysql:dbname=cloud;host=localhost';
$username = 'root';
$password = ''; //pwd di root in mysql di linux

try 
{
	$conn = new PDO($dsn, $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $e) {
	die('Connection failed: ' . $e->getMessage());
}
?>